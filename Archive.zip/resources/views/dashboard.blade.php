@extends('layouts.app')
@include('layouts.subheader')
@section('content')
@endsection
