@extends('layouts.app')



@section('breadcrumb')
    <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
        <li class="breadcrumb-item">
            <a href="{{ route('admin.dashboard') }}" class="text-muted">
                <i class="fas fa-home mr-1"></i> {{ __('item.titles.dashboard') }}
            </a>
        </li>
        <li class="breadcrumb-item">
           <i class="fas fa-money-check-alt mr-1"></i> {{ __('payment.titles.payments_list') }}
        </li>
    </ul>
@endsection

@section('content')
    <div class="card card-custom">
        <div class="card-body">
            <form method="GET" class="mb-4">
                <div class="form-row row py-5">
                    <div class="col-12 col-md mb-2">
                        <label><i class="fas fa-network-wired mr-1"></i> {{ __('payment.filters.select_system') }}</label>
                        <select name="system_id" class="form-control">
                            <option value="">{{ __('payment.filters.select_system') }}</option>
                            @foreach ($systems as $system)
                                <option value="{{ $system->id }}"
                                    {{ request('system_id') == $system->id ? 'selected' : '' }}>
                                    {{ $system->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12 col-md mb-2">
                        <label><i class="fas fa-building mr-1"></i> {{ __('payment.filters.select_branch') }}</label>
                        <select name="branch_id" class="form-control">
                            <option value="">{{ __('payment.filters.select_branch') }}</option>
                            @foreach ($branches as $branch)
                                <option value="{{ $branch->id }}"
                                    {{ request('branch_id') == $branch->id ? 'selected' : '' }}>
                                    {{ $branch->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12 col-md mb-2">
                        <label><i class="fas fa-university mr-1"></i> {{ __('payment.filters.select_academy') }}</label>
                        <select name="academy_id" class="form-control">
                            <option value="">{{ __('payment.filters.select_academy') }}</option>
                            @foreach ($academies as $academy)
                                <option value="{{ $academy->id }}"
                                    {{ request('academy_id') == $academy->id ? 'selected' : '' }}>
                                    {{ $academy->name_en }}
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-12 col-md mb-2">
                        <label><i class="fas fa-search mr-1"></i> {{ __('payment.filters.search_player') }}</label>
                        <input type="text" name="search" class="form-control"
                            placeholder="{{ __('payment.filters.search_player') }}" value="{{ request('search') }}">
                    </div>

                    <div class="col-12 col-md-auto d-flex align-items-end mb-2">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter mr-1"></i> {{ __('payment.actions.filter') }}
                        </button>
                    </div>
                </div>
            </form>
            <div class="mb-4 text-right">
    <a href="{{ route('admin.payments.create') }}" class="btn btn-success">
        <i class="fas fa-plus mr-1"></i> {{ __('payment.actions.create') }}
    </a>
</div>


            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="thead-light">
                        <tr>
                            <th>#</th>
                            <th><i class="fas fa-user"></i> {{ __('payment.fields.player') }}</th>
                            <th><i class="fas fa-cube"></i> {{ __('payment.fields.program') }}</th>
                            <th><i class="fas fa-wallet"></i> {{ __('payment.fields.amount') }}</th>
                            <th><i class="fas fa-check-circle"></i> {{ __('payment.fields.paid') }}</th>
                            <th><i class="fas fa-hourglass-half"></i> {{ __('payment.fields.remaining') }}</th>
                            <th><i class="fas fa-credit-card"></i> {{ __('payment.fields.payment_method') }}</th>
                            <th><i class="fas fa-flag"></i> {{ __('payment.fields.status') }}</th>
                            <th><i class="fas fa-cogs"></i> {{ __('payment.fields.actions') }}</th>

                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($payments as $index => $payment)
                            <tr>
                                <td>{{ $index + $payments->firstItem() }}</td>
                                <td>{{ $payment->player->user->name ?? '-' }}</td>
                                <td>{{ $payment->program->name_en ?? '-' }}</td>
                                <td>{{ $payment->total_price }} {{ $payment->currency }}</td>
                                <td>{{ $payment->paid_amount }}</td>
                                <td>{{ $payment->remaining_amount }}</td>
                                @php
                                    $methodName = $payment->paymentMethod->name ?? null;

                                    $icons = [
                                        'Cash' => 'fas fa-money-bill-wave',
                                        'Credit Card' => 'fas fa-credit-card',
                                        'Debit Card' => 'fas fa-credit-card',
                                        'Bank Transfer' => 'fas fa-university',
                                        'Apple Pay' => 'fab fa-apple',
                                        'Google Pay' => 'fab fa-google',
                                        'PayPal' => 'fab fa-paypal',
                                        'Cheque' => 'fas fa-file-invoice-dollar',
                                        'Installments' => 'fas fa-calendar-alt',
                                    ];

                                    $icon = $icons[$methodName] ?? 'fas fa-question-circle';
                                @endphp

                                <td class="text-center" title="{{ $methodName }}">
                                    <i class="{{ $icon }}"></i>
                                </td>

                                <td>
                                    @php
                                        $statusMap = [
                                            'paid' => ['label' => __('payment.status.paid'), 'icon' => 'fas fa-check'],
                                            'partial' => [
                                                'label' => __('payment.status.partial'),
                                                'icon' => 'fas fa-adjust',
                                            ],
                                            'pending' => [
                                                'label' => __('payment.status.pending'),
                                                'icon' => 'fas fa-clock',
                                            ],
                                        ];
                                        $status = $payment->status;
                                        $data = $statusMap[$status] ?? [
                                            'label' => ucfirst($status),
                                            'icon' => 'fas fa-question',
                                        ];
                                    @endphp
                                    <span class="d-inline-flex align-items-center" style="font-size: 0.875rem;">
                                        <i class="{{ $data['icon'] }} mr-1"></i> {{ $data['label'] }}
                                    </span>
                                </td>
                                <td>
                                    <form action="{{ route('admin.payments.destroy', $payment->id) }}" method="POST"
                                        class="d-inline delete-form">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-sm btn-clean btn-icon delete-button"
                                            title="{{ __('payment.actions.delete') }}">
                                            <i class="la la-trash"></i>
                                        </button>
                                    </form>
                                    <a href="{{ route('admin.payments.edit', $payment->id) }}"
                                        class="btn btn-sm btn-clean btn-icon" title="{{ __('payment.actions.edit') }}">
                                        <i class="la la-edit"></i>
                                    </a>
                                    <a href="{{ route('admin.payments.invoice', $payment->id) }}"
                                    class="btn btn-sm btn-clean btn-icon"
                                    title="{{ __('payment.actions.invoice') }}">
                                        <i class="la la-file-pdf"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>


            <div class="mt-4">
                {{ $payments->withQueryString()->links('pagination::bootstrap-4') }}
            </div>
        </div>
    </div>
@endsection
