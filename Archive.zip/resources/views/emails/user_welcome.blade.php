<p>Hello {{ $user->name }},</p>

<p>Your account has been created. Here are your credentials:</p>

<p>
    <strong>Email:</strong> {{ $user->email }}<br>
    <strong>Password:</strong> {{ $password }}
</p>

<p>You can now log in to the system.</p>

<p>Regards,<br>GSC UAE Team</p>
