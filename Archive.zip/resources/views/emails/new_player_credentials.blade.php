<p>Hello {{ $name }},</p>

<p>Welcome to the platform. Your player account has been created.</p>

<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Password:</strong> {{ $password }}</p>

<p>Please log in and change your password after your first login.</p>

<p>Thanks,<br>Team</p>
