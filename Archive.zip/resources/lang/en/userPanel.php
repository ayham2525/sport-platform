<?php return[
    'user_profile' => 'User Profile',
    'profile' => 'Profile',
    'sign_out' => 'Sign Out'
]?>