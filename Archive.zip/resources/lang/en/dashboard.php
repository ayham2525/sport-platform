<?php
return [
    'Programs' => 'Programs',
    'Classes' => 'Classes',
    'Players' => 'Players',
    'Coaches' => 'Coaches',
    'Academies' => 'Academies',
    'Branches' => 'Branches',
    'Payments' => 'Total Payments',
    'PaidAmount' => 'Total Paid',
    'RemainingAmount' => 'Remaining Amount',
];
