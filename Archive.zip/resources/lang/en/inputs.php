<?php

return [
    'rating' => 'Rating',
    'text' => 'Text',
    'yesno' => 'Yes/No',
];