<?php return [
    'active' => 'Active',
    'inactive' => 'Not Active'
];?>