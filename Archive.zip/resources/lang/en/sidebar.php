<?php
return [
    'evaluations' => 'Evaluations'
];
?>