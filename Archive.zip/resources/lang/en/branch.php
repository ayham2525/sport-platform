<?php

return [
    'id' => 'ID',
    'dashboard' => 'Dashboard',
    'title' => 'Branches',
    'management' => 'Branch Management',
    'new_branch' => 'New Branch',

    // Filters & Selects
    'select_country' => 'Select Country',
    'select_state' => 'Select State',
    'select_city' => 'Select City',
    'select_system' => 'Select System',
    'filter' => 'Filter',

    // Table Headers
    'branch_name' => 'Branch Name',
    'city' => 'City',
    'state' => 'State',
    'country' => 'Country',
    'system' => 'System',
    'status' => 'Status',
    'created_at' => 'Created At',
    'actions' => 'Actions',

    // Status
    'active' => 'Active',
    'inactive' => 'Inactive',

    // Actions
    'edit' => 'Edit',
    'delete' => 'Delete',
    'view' => 'View',
    'view_players' => 'View Players',
    'view_items' => 'View Items',

    // Confirmations
    'delete_confirm_title' => 'Are you sure?',
    'delete_confirm_text' => 'This will delete the branch permanently!',
    'delete_confirm_yes' => 'Yes, delete it!',

    // Player Table
    'players_in' => 'Players in :branch',
    'no_players' => 'No players found for this branch.',
    'name' => 'Name',
    'email' => 'Email',
    'phone' => 'Phone',
    'birth_date' => 'Birth Date',
    'sport' => 'Sport',

    // Search
    'search_placeholder' => 'Search players by name or email...',

    // Items Page
    'item' => 'Item',
    'min_value' => 'Min Value',
    'max_value' => 'Max Value',
    'professional' => 'Professional',
    'notes' => 'Notes',
    'yes' => 'Yes',
    'no' => 'No',
    'no_items_found' => 'No items found.',

    // Pagination
    'search' => 'Search',

    'add_item'=> 'Add Item',
    'select_item' => 'Select Item',
    'select' => 'Select',
    'save' => 'Save',
    'cancel' => 'Cancel',
    'item_added_success' => 'Item added successfully.',
    'item_already_exists' => 'This item is already added to the branch.',
    'item_not_found' => 'Item not found.',
    'edit_item' => 'Edit Item',
    'delete_item' => 'Delete Item',
     'update' => 'Update',
      'item_updated_success' =>  'Item updated successfully.',
    'item_deleted_success' => 'Item deleted successfully.',
];
