<?php
return [
    'evaluations' => 'التقييمات'
];
?>