<?php

return [
    'Programs' => 'البرامج',
    'Classes' => 'الحصص',
    'Players' => 'اللاعبون',
    'Coaches' => 'المدربون',
    'Academies' => 'الأكاديميات',
    'Branches' => 'الفروع',
    'Payments' => 'إجمالي المدفوعات',
    'PaidAmount' => 'إجمالي المبلغ المدفوع',
    'RemainingAmount' => 'المبلغ المتبقي',
];
