<?php return [
    'user_profile' => 'ملف المستخدم',
    'profile' => 'الملف الشخصي',
    'sign_out' => 'تسجيل الخروج'
]; ?>