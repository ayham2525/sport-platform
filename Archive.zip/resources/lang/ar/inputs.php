<?php

return [
    'rating' => 'التقييم',
    'text' => 'نص',
    'yesno' => 'نعم / لا',
];
