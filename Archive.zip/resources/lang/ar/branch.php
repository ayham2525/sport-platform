<?php

return [
    'id' => 'المعرف',
    'dashboard' => 'لوحة التحكم',
    'title' => 'الفروع',
    'management' => 'إدارة الفروع',
    'new_branch' => 'فرع جديد',

    // الفلاتر والاختيارات
    'select_country' => 'اختر الدولة',
    'select_state' => 'اختر المحافظة',
    'select_city' => 'اختر المدينة',
    'select_system' => 'اختر النظام',
    'filter' => 'تصفية',

    // رؤوس الجداول
    'branch_name' => 'اسم الفرع',
    'city' => 'المدينة',
    'state' => 'المحافظة',
    'country' => 'الدولة',
    'system' => 'النظام',
    'status' => 'الحالة',
    'created_at' => 'تاريخ الإنشاء',
    'actions' => 'الإجراءات',

    // الحالة
    'active' => 'نشط',
    'inactive' => 'غير نشط',

    // الإجراءات
    'edit' => 'تعديل',
    'delete' => 'حذف',
    'view' => 'عرض',
    'view_players' => 'عرض اللاعبين',
    'view_items' => 'عرض العناصر',

    // تأكيدات
    'delete_confirm_title' => 'هل أنت متأكد؟',
    'delete_confirm_text' => 'سيتم حذف الفرع نهائيًا!',
    'delete_confirm_yes' => 'نعم، احذفه!',

    // جدول اللاعبين
    'players_in' => 'اللاعبون في :branch',
    'no_players' => 'لا يوجد لاعبين لهذا الفرع.',
    'name' => 'الاسم',
    'email' => 'البريد الإلكتروني',
    'phone' => 'رقم الهاتف',
    'birth_date' => 'تاريخ الميلاد',
    'sport' => 'الرياضة',

    // البحث
    'search_placeholder' => 'ابحث عن اللاعبين بالاسم أو البريد الإلكتروني...',

    // صفحة العناصر
    'item' => 'العنصر',
    'min_value' => 'القيمة الدنيا',
    'max_value' => 'القيمة العليا',
    'professional' => 'احترافي',
    'notes' => 'ملاحظات',
    'yes' => 'نعم',
    'no' => 'لا',
    'no_items_found' => 'لم يتم العثور على عناصر.',

    // التصفية والبحث
    'search' => 'بحث',

    'add_item' => 'إضافة عنصر',
    'select_item' => 'اختر عنصرًا',
    'select' => 'اختر',
    'save' => 'حفظ',
    'cancel' => 'إلغاء',
    'item_added_success' => 'تم إضافة العنصر بنجاح.',
    'item_already_exists' => 'هذا العنصر موجود بالفعل في الفرع.',
    'item_not_found' => 'العنصر غير موجود.',
    'item_min_value' => 'القيمة الدنيا للعنصر',
    'item_max_value' => 'القيمة العليا للعنصر',
    'item_professional' => 'هل هو احترافي؟',
    'item_notes' => 'ملاحظات حول العنصر',
    'edit_item' => 'تعديل العنصر',
    'delete_item' => 'حذف العنصر',
    'update' => 'تحديث',
    'item_updated_success' => 'تم تحديث العنصر بنجاح.',
    'item_deleted_success' => 'تم حذف العنصر بنجاح.',

];
