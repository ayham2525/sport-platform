<?php

return [
    'titles' => [
        'payments_list'     => 'قائمة الدفعات',
        'edit_payment'      => 'تعديل الدفعة',
        'payment_details'   => 'تفاصيل الدفعة',
        'dashboard'         => 'لوحة التحكم',
        'payments'          => 'الدفعات',
        'view_payment'      => 'عرض الدفعة',
    ],

    'fields' => [
        'player'            => 'اللاعب',
        'program'           => 'البرنامج',
        'class_count'       => 'عدد الحصص',
        'base_price'        => 'السعر الأساسي',
        'vat_percent'       => 'نسبة الضريبة (%)',
        'vat_amount'        => 'قيمة الضريبة',
        'total_price'       => 'المبلغ الإجمالي',
        'paid'              => 'المبلغ المدفوع',
        'paid_amount'       => 'المبلغ المدفوع',
        'remaining'         => 'المبلغ المتبقي',
        'remaining_amount'  => 'المبلغ المتبقي',
        'status'            => 'الحالة',
        'payment_method'    => 'طريقة الدفع',
        'currency'          => 'العملة',
        'note'              => 'ملاحظة',
        'actions'           => 'الإجراءات',
        'amount'            => 'المبلغ',
        'category'          => 'الفئة',
        'items'             => 'العناصر',
        'item'              => 'عنصر',
        'quantity'          => 'الكمية',
        'classes'           => 'الحصص',
        'price'             => 'السعر',
    ],

    'status' => [
        'pending'           => 'قيد الانتظار',
        'partial'           => 'مدفوع جزئياً',
        'paid'              => 'مدفوع',
    ],

    'actions' => [
        'edit'              => 'تعديل',
        'save'              => 'حفظ',
        'back'              => 'عودة',
        'filter'            => 'تصفية',
        'create'            => 'إنشاء دفعة',
        'add'               => 'إضافة دفعة',
        'list'              =>  'قائمة الدفعات',
        'add_item'          => 'إضافة عنصر',
        'update'            => 'تحديث الدفعة',
        'view'             => 'عرض الدفعة',


    ],

    'filters' => [
        'select_system'     => 'اختر النظام',
        'select_branch'     => 'اختر الفرع',
        'select_academy'    => 'اختر الأكاديمية',
        'search_player'     => 'بحث باسم اللاعب',
        'select'            => 'اختر',
    ],

    'messages' => [
        'payment_updated_successfully' => 'تم تحديث الدفعة بنجاح.',
        'payment_created_successfully' => 'تم إنشاء الدفعة بنجاح.',
        'payment_deleted_successfully' => 'تم حذف الدفعة بنجاح.',
    ],

    'categories' => [
        'program'   => 'برنامج',
        'uniform'   => 'زي رسمي',
        'asset'     => 'أصل',
        'camp'      => 'معسكر',
        'class'     => 'صف',
    ],
];
