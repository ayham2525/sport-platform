<?php
return [
    'active' => 'مفعل',
    'inactive' => 'غير مفعل',
];