<?php return [
    'settings' => 'الإعدادات',
    'features' => 'الميزات',
    'administrative_areas' => 'المناطق الإدارية',
    'countries' => 'الدول',
    'states' => 'الولايات',
    'cities' => 'المدن',
    'branches_academies' => 'الفروع والأكاديميات',
    'system_management' => 'إدارة النظام',
    'payment_methods' => 'طرق الدفع',
    'branches' => 'الأفرع',
    'users' => 'المستخدمون',
    'system_settings' => 'إعدادات النظام',
    'systems' => 'الأنظمة',
];
?>