<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use App\Models\System;
use App\Models\Evaluation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class EvaluationController extends Controller
{
    public function index()
    {
        $evaluations = Evaluation::with(['system', 'creator'])->latest()->paginate(20);
        return view('admin.evaluations.index', compact('evaluations'));
    }

    public function create()
    {
        $systems = System::all();
        return view('admin.evaluations.create', compact('systems'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'system_id'   => 'required|exists:systems,id',
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'type'        => 'required|in:general,internal,student',
            'start_date'  => 'nullable|date_format:Y-m-d',
            'end_date'    => 'nullable|date_format:Y-m-d|after_or_equal:start_date',
            'is_active'   => 'boolean',
        ]);

        $data['created_by'] = auth()->id();

        $evaluation = Evaluation::create($data);

        log_action('created_evaluation', $evaluation, 'Created evaluation: ' . $evaluation->title);

        return redirect()->route('admin.evaluations.index')->with('success', 'Evaluation created successfully.');
    }


    public function show(Evaluation $evaluation)
    {
        return view('admin.evaluations.show', compact('evaluation'));
    }

    public function edit(Evaluation $evaluation)
    {
        $systems = System::all();
        return view('admin.evaluations.edit', compact('evaluation', 'systems'));
    }

    public function update(Request $request, Evaluation $evaluation)
    {
        $data = $request->validate([
            'system_id'   => 'required|exists:systems,id',
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'type'        => 'required|in:general,internal,student',
            'start_date'  => 'nullable|date',
            'end_date'    => 'nullable|date|after_or_equal:start_date',
            'is_active'   => 'boolean',
        ]);

        $evaluation->update($data);

        log_action('updated_evaluation', $evaluation, 'Updated evaluation: ' . $evaluation->title);

        return redirect()->route('admin.evaluations.index')->with('success', 'Evaluation updated successfully.');
    }

    public function destroy(Evaluation $evaluation)
    {
        // Delete related criteria first
        $evaluation->criteria()->delete();

        // Then delete the evaluation itself
        $evaluation->delete();

        log_action('deleted_evaluation', $evaluation, 'Deleted evaluation: ' . $evaluation->title);

        return redirect()->route('admin.evaluations.index')->with('success', 'Evaluation deleted successfully.');
    }


}
