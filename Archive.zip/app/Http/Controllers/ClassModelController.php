<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Program;
use App\Models\ClassModel;
use Illuminate\Http\Request;

class ClassModelController extends Controller
{
    public function create(Program $program)
    {
        $coaches = User::where('role', 'coach')
            ->where('system_id', $program->system_id)
            ->get();

        return view('admin.class.create', [
            'program' => $program,
            'coaches' => $coaches,
        ]);
    }


   public function store(Request $request, Program $program)
{
    $request->validate([
        'day'         => 'required|in:Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday',
        'start_time'  => 'required|date_format:H:i',
        'end_time'    => 'nullable|date_format:H:i|after:start_time',
        'location'    => 'nullable|string|max:255',
        'coach_id'    => 'nullable|exists:users,id',
    ]);

    // لو اخترت coach_id نجيب اسمه
    $coachName = null;
    if ($request->coach_id) {
        $coach = \App\Models\User::find($request->coach_id);
        $coachName = $coach ? $coach->name : null;
    }

    ClassModel::create([
        'program_id'   => $program->id,
        'academy_id'   => $program->academy_id,
        'day'          => $request->day,
        'start_time'   => $request->start_time,
        'end_time'     => $request->end_time,
        'location'     => $request->location,
        'coach_id'     => $request->coach_id,
        'coach_name'   => $coachName, // نخزن الاسم للنصوص
    ]);

    return redirect()
        ->route('admin.programs.show', $program->id)
        ->with('success', __('class.messages.added'));
}

    public function edit(ClassModel $class)
    {
        return view('admin.class.edit', compact('class'));
    }

    public function update(Request $request, ClassModel $class)
    {
        $request->validate([
            'day' => 'required',
            'start_time' => 'required',
            'end_time' => 'nullable',
            'location' => 'nullable|string',
            'coach_name' => 'nullable|string',
        ]);

        $class->update($request->only('day', 'start_time', 'end_time', 'location', 'coach_name'));

        return redirect()->route('programs.show', $class->program_id)->with('success', __('Class updated successfully.'));
    }

    public function destroy(ClassModel $class)
    {
        $class->delete();
        return back()->with('success', __('Class deleted successfully.'));
    }

    public function byProgram($programId)
    {
        $classes = ClassModel::where('program_id', $programId)
            ->get(['id', 'day', 'start_time', 'end_time', 'location', 'coach_name']);

        return response()->json(['classes' => $classes]);
    }
}
