<?php

namespace App\Http\Controllers;

use App\Models\City;
use App\Models\State;
use App\Models\Branch;
use App\Models\Player;
use App\Models\System;
use App\Models\Academy;
use App\Models\Country;
use App\Models\Program;
use App\Models\ProgramDay;
use Illuminate\Http\Request;

class ProgramController extends Controller
{
    public function index(Request $request)
    {
        $query = Program::with('system', 'branch', 'academy');

        if ($request->filled('search')) {
            $query->where('name_en', 'like', '%' . $request->search . '%');
        }

        if ($request->filled('system_id')) {
            $query->where('system_id', $request->system_id);
        }

        if ($request->filled('branch_id')) {
            $query->where('branch_id', $request->branch_id);
        }

        if ($request->filled('academy_id')) {
            $query->where('academy_id', $request->academy_id);
        }

        $programs = $query->latest()->paginate(10);

        $systems = System::all();
        $branches = Branch::all();
        $academies = Academy::all();

        return view('admin.programs.index', compact('programs', 'systems', 'branches', 'academies'));
    }

    public function create()
    {
        $systems = System::all();
        $countries = Country::all(); // needed for dynamic city loading

        return view('admin.programs.create', compact('systems', 'countries'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'system_id' => 'required',
            'branch_id' => 'required',
            'academy_id' => 'required',
            'name_en' => 'required',
            'class_count' => 'required|integer',
            'price' => 'required|numeric',
        ]);

        $program = Program::create($request->except('days'));

        if ($request->has('days')) {
            foreach ($request->days as $day) {
                ProgramDay::create([
                    'program_id' => $program->id,
                    'day' => $day
                ]);
            }
        }

        return redirect()->route('admin.programs.index')->with('success', __('Program created successfully.'));
    }

    public function show(Program $program)
    {
        $program->load('days', 'classes', 'system', 'branch', 'academy');
        return view('admin.programs.show', compact('program'));
    }

    public function edit(Program $program)
    {
        $systems = System::all();
        $branches = Branch::where('system_id', $program->system_id)->get();
        $academies = Academy::where('branch_id', $program->branch_id)->get();
        $countries = Country::all();

        $city = optional($program->branch)->city;
        $state = optional($city)->state;
        $states = $state ? State::where('country_id', $state->country_id)->get() : collect();
        $cities = $state ? City::where('state_id', $state->id)->get() : collect();

        return view('admin.programs.edit', compact(
            'program', 'systems', 'branches', 'academies',
            'countries', 'states', 'cities'
        ));
    }


    public function update(Request $request, Program $program)
    {
        $program->update($request->except('days'));

        $program->days()->delete();
        if ($request->has('days')) {
            foreach ($request->days as $day) {
                ProgramDay::create([
                    'program_id' => $program->id,
                    'day' => $day
                ]);
            }
        }

        return redirect()->route('admin.programs.index')->with('success', __('Program updated successfully.'));
    }

    public function destroy(Program $program)
    {
        $program->delete();
        return redirect()->back()->with('success', __('Program deleted.'));
    }

    public function players(Program $program)
    {
        $players = Player::whereHas('programs', function ($q) use ($program) {
            $q->where('program_id', $program->id);
        })->with('user', 'branch', 'academy', 'sport')->paginate(20);

        return view('admin.programs.players', compact('program', 'players'));
    }

}
