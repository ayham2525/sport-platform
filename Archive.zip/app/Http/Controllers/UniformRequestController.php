<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Player;
use App\Models\System;
use App\Models\Item;
use App\Models\Currency;
use Illuminate\Http\Request;
use App\Models\UniformRequest;
use Illuminate\Support\Facades\Auth;

class UniformRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        $systems = [];
        $branches = [];
        $players = [];
        $items = [];

        $query = UniformRequest::query()->with(['player.user', 'item', 'branch', 'system']);
        $currencies = Currency::pluck('code', 'id');

        if ($user->role === 'full_admin') {
            $systems = System::pluck('name', 'id');

            if ($request->filled('system_id')) {
                $query->where('system_id', $request->system_id);
                $branches = Branch::where('system_id', $request->system_id)->pluck('name', 'id');

                // Load players for selected system
                $players = Player::whereHas('branch', function ($q) use ($request) {
                    $q->where('system_id', $request->system_id);
                })->with('user:id,name')->get();

                // Load items for the selected system
                $items = Item::where('system_id', $request->system_id)->pluck(app()->getLocale() === 'ar' ? 'name_ar' : 'name_en', 'id');
            }
        } else {
            if ($user->branch_id) {
                $query->where('branch_id', $user->branch_id);

                // Load players for user's branch
                $players = Player::where('branch_id', $user->branch_id)->with('user:id,name')->get();

                // Load items for user's branch/system if needed
                $items = Item::where('system_id', $user->system_id)->pluck(app()->getLocale() === 'ar' ? 'name_ar' : 'name_en', 'id');
            }
        }

        if ($request->filled('branch_id')) {
            $query->where('branch_id', $request->branch_id);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $uniformRequests = $query->latest()->paginate(10);

        return view('admin.uniform_requests.index', compact(
            'uniformRequests',
            'systems',
            'branches',
            'players',
            'items',
            'currencies',
            'request'
        ));
    }

    public function create()
    {
        $user = Auth::user();
        $systems = [];
        $branches = [];
        $players = [];
        $items = [];
        $currencies = Currency::all();

        if ($user->role === 'full_admin') {
            $systems = System::pluck('name', 'id');
            $branches = Branch::pluck('name', 'id');
            $players = Player::with('user:id,name')->get();
            $items = Item::pluck(app()->getLocale() === 'ar' ? 'name_ar' : 'name_en', 'id');
        } else {
            $branches = Branch::where('id', $user->branch_id)->pluck('name', 'id');
            $players = Player::where('branch_id', $user->branch_id)->with('user:id,name')->get();
            $items = Item::where('system_id', $user->system_id)->pluck(app()->getLocale() === 'ar' ? 'name_ar' : 'name_en', 'id');
        }

        return view('admin.uniform_requests.create', compact('systems', 'branches', 'players', 'items', 'currencies'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'system_id' => 'nullable|exists:systems,id',
            'branch_id' => 'required|exists:branches,id',
            'player_id' => 'required|exists:players,id',
            'item_id' => 'required|exists:items,id',
            'size' => 'required|string|max:50',
            'color' => 'required|string|max:50',
            'quantity' => 'required|integer|min:1',
            'amount' => 'required|numeric|min:0',
            'currency_id' => 'required|exists:currencies,id',
            'notes' => 'nullable|string',
        ]);

        $validated['status'] = 'requested';
        $validated['requested_at'] = now();
        $validated['request_date'] = now();


        UniformRequest::create($validated);

        return redirect()->route('admin.uniform-requests.index')
            ->with('success', __('uniform_requests.created_successfully'));
    }

    public function edit($id)
    {
        $user = Auth::user();
        $uniformRequest = UniformRequest::findOrFail($id);

        $systems = [];
        $branches = [];
        $players = [];
        $items = [];
        $currencies = Currency::all();

        if ($user->role === 'full_admin') {
            $systems = System::pluck('name', 'id');
            $branches = Branch::where('system_id', $uniformRequest->system_id)->pluck('name', 'id');
            $players = Player::whereHas('branch', function ($q) use ($uniformRequest) {
                $q->where('system_id', $uniformRequest->system_id);
            })->with('user:id,name')->get();
            $items = Item::where('system_id', $uniformRequest->system_id)
                ->pluck(app()->getLocale() === 'ar' ? 'name_ar' : 'name_en', 'id');
        } else {
            $branches = Branch::where('id', $user->branch_id)->pluck('name', 'id');
            $players = Player::where('branch_id', $user->branch_id)->with('user:id,name')->get();
            $items = Item::where('system_id', $user->system_id)
                ->pluck(app()->getLocale() === 'ar' ? 'name_ar' : 'name_en', 'id');
        }

        return view('admin.uniform_requests.edit', compact('uniformRequest', 'systems', 'branches', 'players', 'items', 'currencies'));
    }

   public function update(Request $request, $id)
{
    $uniformRequest = UniformRequest::findOrFail($id);

    $validated = $request->validate([
        'system_id' => 'nullable|exists:systems,id',
        'branch_id' => 'required|exists:branches,id',
        'player_id' => 'required|exists:players,id',
        'item_id' => 'required|exists:items,id',
        'size' => 'required|string|max:50',
        'color' => 'required|string|max:50',
        'quantity' => 'required|integer|min:1',
        'amount' => 'required|numeric|min:0',
        'currency_id' => 'required|exists:currencies,id',
        'notes' => 'nullable|string',
    ]);

    $validated['updated_at'] = now();

    $uniformRequest->update($validated);

    return redirect()->route('admin.uniform-requests.index')
        ->with('success', __('uniform_requests.updated_successfully'));
}

}
