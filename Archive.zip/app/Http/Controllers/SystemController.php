<?php
namespace App\Http\Controllers;

use App\Models\System;
use Illuminate\Http\Request;

class SystemController extends Controller
{
    // Show all systems
    public function index()
    {
        $systems = System::latest()->paginate(10);
        return view('admin.system.index', compact('systems'));
    }

    // Show form to create a new system
    public function create()
    {
        return view('admin.system.create');
    }

    // Store new system
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        System::create($request->only('name', 'description'));

        return redirect()->route('admin.systems.index')->with('success', 'System created successfully.');
    }

    // Show single system
    public function show(System $system)
    {
        return view('admin.system.show', compact('system'));
    }

    // Show edit form
    public function edit(System $system)
    {
        return view('admin.system.edit', compact('system'));
    }

    // Update the system
    public function update(Request $request, System $system)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $system->update($request->only('name', 'description'));

        return redirect()->route('admin.systems.index')->with('success', 'System updated successfully.');
    }

    // Delete the system
    public function destroy(System $system)
    {
        $system->delete();
        return redirect()->route('admin.systems.index')->with('success', 'System deleted successfully.');
    }
}
