<?php


namespace App\Http\Controllers;

use App\Models\Academy;
use App\Models\Branch;
use Illuminate\Http\Request;

class AcademyController extends Controller
{
    public function index(Request $request)
    {
        $query = Academy::with('branch');

        if ($request->filled('branch_id')) {
            $query->where('branch_id', $request->branch_id);
        }

        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name_en', 'like', '%' . $request->search . '%')
                  ->orWhere('name_ar', 'like', '%' . $request->search . '%')
                  ->orWhere('name_ur', 'like', '%' . $request->search . '%');
            });
        }

        $academies = $query->latest()->paginate(10);
        $branches = Branch::all();

        return view('admin.academy.index', compact('academies', 'branches'));
    }

    public function create()
    {
        $branches = Branch::all();
        return view('admin.academy.create', compact('branches'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'branch_id' => 'required|exists:branches,id',
            'name_en' => 'required|string|max:255',
            'name_ar' => 'nullable|string|max:255',
            'name_ur' => 'nullable|string|max:255',
            'contact_email' => 'nullable|email',
            'phone' => 'nullable|string|max:20',
            'is_active' => 'nullable|boolean',
        ]);

        Academy::create([
            'branch_id' => $request->branch_id,
            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'name_ur' => $request->name_ur,
            'description_en' => $request->description_en,
            'description_ar' => $request->description_ar,
            'description_ur' => $request->description_ur,
            'contact_email' => $request->contact_email,
            'phone' => $request->phone,
            'is_active' => $request->is_active ?? false,
        ]);

        return redirect()->route('admin.academies.index')->with('success', 'Academy created successfully.');
    }

    public function show($id)
    {
        $academy = Academy::with('branch')->findOrFail($id);
        return view('admin.academy.show', compact('academy'));
    }

    public function edit($id)
    {
        $academy = Academy::findOrFail($id);
        $branches = Branch::all();

        return view('admin.academy.edit', compact('academy', 'branches'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'branch_id' => 'required|exists:branches,id',
            'name_en' => 'required|string|max:255',
            'name_ar' => 'nullable|string|max:255',
            'name_ur' => 'nullable|string|max:255',
            'contact_email' => 'nullable|email',
            'phone' => 'nullable|string|max:20',
            'is_active' => 'nullable|boolean',
        ]);

        $academy = Academy::findOrFail($id);
        $academy->update([
            'branch_id' => $request->branch_id,
            'name_en' => $request->name_en,
            'name_ar' => $request->name_ar,
            'name_ur' => $request->name_ur,
            'description_en' => $request->description_en,
            'description_ar' => $request->description_ar,
            'description_ur' => $request->description_ur,
            'contact_email' => $request->contact_email,
            'phone' => $request->phone,
            'is_active' => $request->is_active ?? false,
        ]);

        return redirect()->route('admin.academies.index')->with('success', 'Academy updated successfully.');
    }

    public function destroy($id)
    {
        $academy = Academy::findOrFail($id);
        $academy->delete();

        return redirect()->route('admin.academies.index')->with('success', 'Academy deleted successfully.');
    }
}
