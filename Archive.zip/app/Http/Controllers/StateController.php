<?php 

namespace App\Http\Controllers;

use App\Models\State;
use App\Models\Country;
use Illuminate\Http\Request;

class StateController extends Controller
{
    public function index()
    {
        $states = State::with('country')->get();
        return view('admin.state.index', compact('states'));
    }

    public function show($id)
    {
        $state = State::with('country')->findOrFail($id);
        return view('admin.state.show', compact('state'));
    }

    public function create()
    {
        $countries = Country::where('is_active', 1)->get();
        return view('admin.state.create', compact('countries'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'country_id' => 'required|exists:countries,id',
            'is_active' => 'nullable|boolean',
        ]);

        State::create([
            'name' => $request->name,
            'country_id' => $request->country_id,
            'is_active' => $request->is_active ?? false,
        ]);

        return redirect()->route('admin.states.index')->with('success', 'State created successfully.');
    }

    public function edit($id)
    {
        $state = State::findOrFail($id);
        $countries = Country::where('is_active', 1)->get();
        return view('admin.state.edit', compact('state', 'countries'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'country_id' => 'required|exists:countries,id',
            'is_active' => 'nullable|boolean',
        ]);

        $state = State::findOrFail($id);
        $state->update([
            'name' => $request->name,
            'country_id' => $request->country_id,
            'is_active' => $request->is_active ?? false,
        ]);

        return redirect()->route('admin.states.index')->with('success', 'State updated successfully.');
    }

    // 🗑️ Delete state
    public function destroy($id)
    {
        $state = State::findOrFail($id);
        $state->delete();

        return redirect()->route('admin.states.index')->with('success', 'State deleted successfully.');
    }

    public function getStatesByCountry(Request $request)
    {
        $states = State::where('country_id', $request->country_id)
            ->where('is_active', 1)
            ->select('id', 'name')
            ->get();

        return response()->json($states);
    }
}
