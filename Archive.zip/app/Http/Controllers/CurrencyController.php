<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Currency;
use Illuminate\Http\Request;

class CurrencyController extends Controller
{
    public function index()
    {
        $currencies = Currency::orderBy('code')->get();
        return view('admin.currencies.index', compact('currencies'));
    }

    public function create()
    {
        return view('admin.currencies.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'code'   => 'required|string|size:3|unique:currencies,code',
            'name'   => 'required|string|max:100',
            'symbol' => 'nullable|string|max:10',
            'active' => 'boolean',
        ]);

        Currency::create($request->only(['code', 'name', 'symbol', 'active']));

        return redirect()->route('admin.currencies.index')->with('success', __('Currency created successfully.'));
    }

    public function edit(Currency $currency)
    {
        return view('admin.currencies.edit', compact('currency'));
    }

    public function update(Request $request, Currency $currency)
    {
        $request->validate([
            'code'   => 'required|string|size:3|unique:currencies,code,' . $currency->id,
            'name'   => 'required|string|max:100',
            'symbol' => 'nullable|string|max:10',
            'active' => 'boolean',
        ]);

        $currency->update($request->only(['code', 'name', 'symbol', 'active']));

        return redirect()->route('admin.currencies.index')->with('success', __('Currency updated successfully.'));
    }

    public function destroy(Currency $currency)
    {
        $currency->delete();

        return redirect()->route('admin.currencies.index')->with('success', __('Currency deleted successfully.'));
    }
}
